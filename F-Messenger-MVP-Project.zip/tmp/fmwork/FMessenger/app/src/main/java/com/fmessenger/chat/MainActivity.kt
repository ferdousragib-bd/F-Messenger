package com.fmessenger.chat

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.google.android.gms.location.LocationServices
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.Query
import com.google.firebase.storage.FirebaseStorage
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import java.util.UUID
import kotlin.math.*

private val Navy = Color(0xFF123B70)
private val Blue = Color(0xFF247BDB)
private val Pale = Color(0xFFF1F6FC)
private val db by lazy { FirebaseFirestore.getInstance() }
private val auth by lazy { FirebaseAuth.getInstance() }
private val storage by lazy { FirebaseStorage.getInstance() }

data class Person(val uid: String = "", val name: String = "", val username: String = "", val phone: String = "", val photoUrl: String = "")
data class ChatMessage(val id: String = "", val senderId: String = "", val text: String = "", val createdAt: Long = 0L)
data class FeedPost(val id: String = "", val uid: String = "", val author: String = "", val username: String = "", val text: String = "", val mediaUrl: String = "", val mediaType: String = "", val createdAt: Long = 0L)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme(colorScheme = lightColorScheme(primary = Blue, background = Pale)) { MessengerApp() } }
    }
}

@Composable fun MessengerApp() {
    var currentUser by remember { mutableStateOf(auth.currentUser?.uid) }
    var selected by remember { mutableStateOf<Person?>(null) }
    DisposableEffect(Unit) { val l = FirebaseAuth.AuthStateListener { currentUser = it.currentUser?.uid }; auth.addAuthStateListener(l); onDispose { auth.removeAuthStateListener(l) } }
    Surface(Modifier.fillMaxSize(), color = Pale) {
        if (currentUser == null) AuthScreen { currentUser = it }
        else if (selected != null) ChatScreen(selected!!, onBack = { selected = null })
        else MainTabs(onSelect = { selected = it }, onSignOut = { auth.signOut(); currentUser = null })
    }
}

@Composable fun AuthScreen(onSignedIn: (String) -> Unit) {
    var register by remember { mutableStateOf(false) }; var name by remember { mutableStateOf("") }; var username by remember { mutableStateOf("") }; var phone by remember { mutableStateOf("") }; var email by remember { mutableStateOf("") }; var password by remember { mutableStateOf("") }; var busy by remember { mutableStateOf(false) }; var error by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()
    Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center) {
        Box(Modifier.size(70.dp).background(Blue, CircleShape), contentAlignment = Alignment.Center) { Text("F", color = Color.White, style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold) }
        Spacer(Modifier.height(14.dp)); Text("F Messenger", style = MaterialTheme.typography.headlineMedium, color = Navy, fontWeight = FontWeight.Bold); Text(if (register) "বাংলাদেশের মানুষের সঙ্গে যুক্ত হোন" else "আপনার অ্যাকাউন্টে প্রবেশ করুন", color = Color.Gray)
        Spacer(Modifier.height(16.dp))
        if (register) { OutlinedTextField(name, { name = it }, label = { Text("আপনার নাম") }, modifier = Modifier.fillMaxWidth()); OutlinedTextField(username, { username = it.lowercase().replace(" ", "") }, label = { Text("Username") }, modifier = Modifier.fillMaxWidth()); OutlinedTextField(phone, { phone = it }, label = { Text("ফোন নম্বর") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone), modifier = Modifier.fillMaxWidth()) }
        OutlinedTextField(email, { email = it }, label = { Text("ইমেইল") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email), modifier = Modifier.fillMaxWidth()); OutlinedTextField(password, { password = it }, label = { Text("পাসওয়ার্ড (কমপক্ষে ৬ অক্ষর)") }, visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth())
        if (error.isNotBlank()) Text(error, color = MaterialTheme.colorScheme.error)
        Button(onClick = { scope.launch { busy = true; error = ""; try { if (register) { require(name.isNotBlank() && username.isNotBlank() && phone.isNotBlank()) { "নাম, Username ও ফোন নম্বর দিন" }; val result = auth.createUserWithEmailAndPassword(email.trim(), password).await(); val uid = result.user!!.uid; val profile = mapOf("uid" to uid, "name" to name.trim(), "username" to username.trim(), "usernameLower" to username.trim().lowercase(), "phone" to phone.trim(), "phoneDigits" to phone.filter { it.isDigit() }, "email" to email.trim(), "country" to "Bangladesh", "discoverable" to true, "createdAt" to System.currentTimeMillis()); db.collection("users").document(uid).set(profile).await(); db.collection("publicProfiles").document(uid).set(mapOf("uid" to uid, "name" to name.trim(), "username" to username.trim(), "country" to "Bangladesh", "discoverable" to true)).await(); onSignedIn(uid) } else { val r = auth.signInWithEmailAndPassword(email.trim(), password).await(); onSignedIn(r.user!!.uid) } } catch (e: Exception) { error = e.localizedMessage ?: "আবার চেষ্টা করুন" }; busy = false } }, enabled = !busy, modifier = Modifier.fillMaxWidth()) { Text(if (busy) "অপেক্ষা করুন..." else if (register) "অ্যাকাউন্ট তৈরি করুন" else "লগইন") }
        TextButton(onClick = { register = !register; error = "" }, modifier = Modifier.align(Alignment.CenterHorizontally)) { Text(if (register) "আগে অ্যাকাউন্ট আছে? লগইন" else "নতুন অ্যাকাউন্ট খুলুন") }
    }
}

@Composable fun MainTabs(onSelect: (Person) -> Unit, onSignOut: () -> Unit) {
    var tab by remember { mutableStateOf(0) }
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().background(Navy).padding(horizontal = 16.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) { Text("F Messenger", color = Color.White, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f)); IconButton(onClick = onSignOut) { Icon(Icons.Default.ExitToApp, contentDescription = "লগআউট", tint = Color.White) } }
        when (tab) { 0 -> FeedScreen(); 1 -> DiscoverScreen(onSelect); else -> ProfileScreen() }
        NavigationBar(containerColor = Color.White) {
            NavigationBarItem(selected = tab == 0, onClick = { tab = 0 }, icon = { Icon(Icons.Default.Home, null) }, label = { Text("ফিড") })
            NavigationBarItem(selected = tab == 1, onClick = { tab = 1 }, icon = { Icon(Icons.Default.People, null) }, label = { Text("মানুষ খুঁজুন") })
            NavigationBarItem(selected = tab == 2, onClick = { tab = 2 }, icon = { Icon(Icons.Default.Person, null) }, label = { Text("প্রোফাইল") })
        }
    }
}

@Composable fun FeedScreen() {
    val uid = auth.currentUser?.uid ?: return; val scope = rememberCoroutineScope(); var posts by remember { mutableStateOf(listOf<FeedPost>()) }; var draft by remember { mutableStateOf("") }; var error by remember { mutableStateOf("") }; var busy by remember { mutableStateOf(false) }
    DisposableEffect(Unit) { val l = db.collection("posts").orderBy("createdAt", Query.Direction.DESCENDING).limit(50).addSnapshotListener { s, e -> if (e != null) error = e.localizedMessage ?: "ফিড লোড হয়নি" else posts = s?.documents?.mapNotNull { d -> d.toObject(FeedPost::class.java)?.copy(id = d.id) } ?: emptyList() }; onDispose { l.remove() } }
    Column(Modifier.fillMaxSize().padding(12.dp)) {
        Text("আপনার নিউজ ফিড", color = Navy, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        OutlinedTextField(draft, { draft = it }, modifier = Modifier.fillMaxWidth(), label = { Text("আপনার মনের কথা লিখুন...") }, minLines = 2)
        Button(onClick = { val body = draft.trim(); if (body.isNotBlank()) scope.launch { busy = true; try { val profile = db.collection("users").document(uid).get().await(); db.collection("posts").add(mapOf("uid" to uid, "author" to (profile.getString("name") ?: "F Messenger User"), "username" to (profile.getString("username") ?: ""), "text" to body, "mediaUrl" to "", "mediaType" to "", "createdAt" to System.currentTimeMillis())).await(); draft = "" } catch (e: Exception) { error = e.localizedMessage ?: "পোস্ট করা যায়নি" }; busy = false } }, enabled = !busy, modifier = Modifier.align(Alignment.End)) { Text(if (busy) "পোস্ট হচ্ছে..." else "পোস্ট করুন") }
        if (error.isNotBlank()) Text(error, color = MaterialTheme.colorScheme.error)
        HorizontalDivider(Modifier.padding(vertical = 8.dp))
        LazyColumn { items(posts) { p -> Card(Modifier.fillMaxWidth().padding(vertical = 5.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) { Column(Modifier.padding(14.dp)) { Text(p.author, color = Navy, fontWeight = FontWeight.Bold); if (p.username.isNotBlank()) Text("@${p.username}", color = Color.Gray, style = MaterialTheme.typography.labelSmall); Spacer(Modifier.height(8.dp)); Text(p.text) } } } }
    }
}

@Composable fun DiscoverScreen(onSelect: (Person) -> Unit) {
    val uid = auth.currentUser?.uid ?: return; val context = LocalContext.current; val scope = rememberCoroutineScope(); var people by remember { mutableStateOf(listOf<Person>()) }; var status by remember { mutableStateOf("সারা বাংলাদেশের Discover-এ সম্মতি দেওয়া মানুষ দেখুন") }; var nearby by remember { mutableStateOf(false) }; var busy by remember { mutableStateOf(false) }
    val permission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted -> if (granted) { val client = LocationServices.getFusedLocationProviderClient(context); try { client.lastLocation.addOnSuccessListener { loc -> if (loc != null) { scope.launch { try { db.collection("users").document(uid).update("nearbyEnabled", true).await(); db.collection("publicProfiles").document(uid).update(mapOf("latitude" to (loc.latitude * 100).roundToInt() / 100.0, "longitude" to (loc.longitude * 100).roundToInt() / 100.0, "nearbyEnabled" to true)).await(); loadPeople(uid, loc.latitude, loc.longitude, true, { people = it }, { status = it }) } catch (e: Exception) { status = e.localizedMessage ?: "অবস্থান সংরক্ষণ হয়নি" } } } else status = "অবস্থান পাওয়া যায়নি। পরে আবার চেষ্টা করুন।" } } catch (_: SecurityException) { status = "Location permission প্রয়োজন" } } else status = "অনুমতি না দেওয়ায় আশেপাশের মানুষ দেখানো যাচ্ছে না" }
    Column(Modifier.fillMaxSize().padding(14.dp)) {
        Text("Auto Find People", color = Navy, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Text("বাংলাদেশের মানুষ অথবা আপনার কাছাকাছি ব্যবহারকারী খুঁজুন", color = Color.Gray)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { nearby = false; busy = true; scope.launch { loadPeople(uid, null, null, false, { people = it; busy = false }, { status = it; busy = false }) } }, modifier = Modifier.weight(1f)) { Text("সারা বাংলাদেশ") }
            OutlinedButton(onClick = { nearby = true; if (ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) { val c = LocationServices.getFusedLocationProviderClient(context); try { c.lastLocation.addOnSuccessListener { loc -> if (loc != null) scope.launch { try { db.collection("users").document(uid).update("nearbyEnabled", true).await(); db.collection("publicProfiles").document(uid).update(mapOf("latitude" to (loc.latitude * 100).roundToInt() / 100.0, "longitude" to (loc.longitude * 100).roundToInt() / 100.0, "nearbyEnabled" to true)).await(); loadPeople(uid, loc.latitude, loc.longitude, true, { people = it }, { status = it }) } catch (e: Exception) { status = e.localizedMessage ?: "অবস্থান সংরক্ষণ হয়নি" } } else status = "অবস্থান পাওয়া যায়নি" } } catch (_: SecurityException) {} } else permission.launch(Manifest.permission.ACCESS_FINE_LOCATION) }, modifier = Modifier.weight(1f)) { Text("আশেপাশে") }
        }
        Text(status, color = Color.Gray, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(vertical = 8.dp))
        if (busy) CircularProgressIndicator(Modifier.align(Alignment.CenterHorizontally))
        LazyColumn { items(people) { p -> ListItem(headlineContent = { Text(p.name.ifBlank { p.username }) }, supportingContent = { Text("@${p.username}") }, leadingContent = { Box(Modifier.size(42.dp).background(Blue, CircleShape), contentAlignment = Alignment.Center) { Text(p.name.take(1).uppercase(), color = Color.White) } }, modifier = Modifier.clickable { onSelect(p) }); HorizontalDivider() } }
    }
}

private suspend fun loadPeople(uid: String, lat: Double?, lon: Double?, nearby: Boolean, done: (List<Person>) -> Unit, fail: (String) -> Unit) {
    try {
        val snap = db.collection("publicProfiles").whereEqualTo("country", "Bangladesh").whereEqualTo("discoverable", true).limit(150).get().await()
        var list = snap.documents.filter { it.id != uid }.mapNotNull { it.toObject(Person::class.java) }
        if (nearby && lat != null && lon != null) {
            list = snap.documents.filter { it.id != uid }.filter { d -> val a = d.getDouble("latitude"); val b = d.getDouble("longitude"); d.getBoolean("nearbyEnabled") == true && a != null && b != null && distanceKm(lat, lon, a, b) <= 50.0 }.mapNotNull { it.toObject(Person::class.java) }
            fail("আপনার ৫০ কিমির মধ্যে সম্মতি দেওয়া ব্যবহারকারী")
        } else fail("সারা বাংলাদেশের সম্মতি দেওয়া ব্যবহারকারী")
        done(list)
    } catch (e: Exception) { fail(e.localizedMessage ?: "ব্যবহারকারী লোড করা যায়নি") }
}
private fun distanceKm(a: Double, b: Double, c: Double, d: Double): Double { val r = 6371.0; val x = Math.toRadians(c-a); val y = Math.toRadians(d-b); val z = sin(x/2).pow(2) + cos(Math.toRadians(a))*cos(Math.toRadians(c))*sin(y/2).pow(2); return 2*r*asin(sqrt(z)) }

@Composable fun ProfileScreen() {
    val uid = auth.currentUser?.uid ?: return; var name by remember { mutableStateOf("") }; var username by remember { mutableStateOf("") }; var discoverable by remember { mutableStateOf(true) }; var message by remember { mutableStateOf("") }; val scope = rememberCoroutineScope()
    LaunchedEffect(uid) { val d = db.collection("users").document(uid).get().await(); name = d.getString("name") ?: ""; username = d.getString("username") ?: ""; discoverable = d.getBoolean("discoverable") ?: true }
    Column(Modifier.fillMaxSize().padding(20.dp)) { Text("আমার প্রোফাইল", color = Navy, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold); Spacer(Modifier.height(16.dp)); Text(name, style = MaterialTheme.typography.headlineSmall); Text("@$username", color = Color.Gray); HorizontalDivider(Modifier.padding(vertical = 16.dp)); Row(verticalAlignment = Alignment.CenterVertically) { Column(Modifier.weight(1f)) { Text("Auto Find People-এ দেখান", fontWeight = FontWeight.SemiBold); Text("বন্ধ করলে অন্যরা Discover-এ আপনাকে দেখবে না", style = MaterialTheme.typography.bodySmall, color = Color.Gray) }; Switch(checked = discoverable, onCheckedChange = { v -> discoverable = v; scope.launch { try { db.collection("users").document(uid).update("discoverable", v).await(); db.collection("publicProfiles").document(uid).update("discoverable", v).await(); message = "সেটিংস সংরক্ষণ হয়েছে" } catch (e: Exception) { message = e.localizedMessage ?: "সংরক্ষণ হয়নি" } } }) }; if (message.isNotBlank()) Text(message, color = Blue) }
}

@Composable fun ChatScreen(person: Person, onBack: () -> Unit) {
    val myUid = auth.currentUser?.uid ?: return; val chatId = listOf(myUid, person.uid).sorted().joinToString("_"); var messages by remember { mutableStateOf(listOf<ChatMessage>()) }; var draft by remember { mutableStateOf("") }; var error by remember { mutableStateOf("") }; val scope = rememberCoroutineScope()
    DisposableEffect(chatId) { val listener: ListenerRegistration = db.collection("chats").document(chatId).collection("messages").orderBy("createdAt", Query.Direction.ASCENDING).addSnapshotListener { snap, e -> if (e != null) error = e.localizedMessage ?: "মেসেজ লোড হয়নি" else messages = snap?.documents?.mapNotNull { d -> d.toObject(ChatMessage::class.java)?.copy(id = d.id) } ?: emptyList() }; onDispose { listener.remove() } }
    Column(Modifier.fillMaxSize()) { Row(Modifier.fillMaxWidth().background(Navy).padding(10.dp), verticalAlignment = Alignment.CenterVertically) { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null, tint = Color.White) }; Column { Text(person.name, color = Color.White, fontWeight = FontWeight.Bold); Text("@${person.username}", color = Color(0xFFD8E8FF)) } }; LazyColumn(Modifier.weight(1f).fillMaxWidth().padding(12.dp)) { items(messages) { m -> Row(Modifier.fillMaxWidth(), horizontalArrangement = if (m.senderId == myUid) Arrangement.End else Arrangement.Start) { Surface(color = if (m.senderId == myUid) Blue else Color.White, shape = RoundedCornerShape(15.dp)) { Text(m.text, Modifier.padding(12.dp), color = if (m.senderId == myUid) Color.White else Navy) } }; Spacer(Modifier.height(7.dp)) } }; if (error.isNotBlank()) Text(error, color = MaterialTheme.colorScheme.error); Row(Modifier.fillMaxWidth().background(Color.White).padding(8.dp), verticalAlignment = Alignment.CenterVertically) { OutlinedTextField(draft, { draft = it }, Modifier.weight(1f), placeholder = { Text("মেসেজ লিখুন...") }, maxLines = 3); IconButton(onClick = { val t = draft.trim(); if (t.isNotBlank()) scope.launch { try { val ref = db.collection("chats").document(chatId); ref.set(mapOf("members" to listOf(myUid, person.uid), "lastMessage" to t, "updatedAt" to System.currentTimeMillis())).await(); ref.collection("messages").add(mapOf("senderId" to myUid, "text" to t, "createdAt" to System.currentTimeMillis())).await(); draft = "" } catch (e: Exception) { error = e.localizedMessage ?: "পাঠানো যায়নি" } } }) { Icon(Icons.Default.Send, null, tint = Blue) } } }
}
