# F Messenger — Android project (Firebase)

এই সংস্করণে আছে:
- ইমেইল/পাসওয়ার্ড দিয়ে রেজিস্ট্রেশন ও লগইন
- বাংলাদেশভিত্তিক Auto Find People (Discoverable সম্মতি দেওয়া অ্যাকাউন্ট)
- আশেপাশের মানুষ খোঁজা: ব্যবহারকারী নিজে Location permission দিয়ে “আশেপাশে” চাপলে সর্বোচ্চ ৫০ কিমির মধ্যে খোঁজে; অবস্থান অন্যদের কাছে দেখানো হয় না
- সাধারণ লেখা পোস্টের নিউজ ফিড
- ব্যক্তিগত টেক্সট চ্যাট
- Discover-এ না দেখানোর privacy switch

## জরুরি সীমাবদ্ধতা
এটি প্রাথমিক MVP, Facebook/TikTok-এর সম্পূর্ণ বিকল্প নয়। এই সংস্করণে এখনো ছবি/ভিডিও পোস্ট, Reels প্লেয়ার, ভয়েস মেসেজ, অডিও/ভিডিও লাইভ কল, লাইক/কমেন্ট/শেয়ার ও রিপোর্ট/ব্লক ব্যবস্থা নেই। এগুলো পরবর্তী ধাপে যোগ করতে হবে।

## Firebase সেটআপ
1. Firebase Console → Authentication → Sign-in method → Email/Password চালু করুন।
2. Firestore Database তৈরি করুন।
3. Storage চালু করুন (Firebase Console-এর নির্দেশনা অনুসরণ করুন; কিছু প্রকল্পে billing plan লাগতে পারে)।
4. Firestore Rules-এ `firestore.rules` এবং Storage Rules-এ `storage.rules` প্রকাশ করুন।
5. `app/google-services.json`-এ Android package `com.fmessenger.chat`-এর সঠিক Firebase config থাকতে হবে।

## Build
GitHub Actions workflow দিয়ে `gradle assembleDebug` চালিয়ে `app/build/outputs/apk/debug/app-debug.apk` তৈরি করা যাবে। এটি debug APK; প্রকাশের আগে release signing, security rules review, abuse reporting/moderation ও privacy policy দরকার।
