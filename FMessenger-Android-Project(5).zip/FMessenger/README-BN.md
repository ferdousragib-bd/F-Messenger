# F Messenger — Android project (Firebase)

এই সংস্করণে আছে:
- ইমেইল/পাসওয়ার্ড দিয়ে রেজিস্ট্রেশন ও লগইন
- বাংলাদেশভিত্তিক Auto Find People (Discoverable সম্মতি দেওয়া অ্যাকাউন্ট)
- আশেপাশের মানুষ খোঁজা: ব্যবহারকারী নিজে Location permission দিয়ে “আশেপাশে” চাপলে সর্বোচ্চ ৫০ কিমির মধ্যে খোঁজে; অবস্থান অন্যদের কাছে দেখানো হয় না
- সাধারণ লেখা পোস্টের নিউজ ফিড
- ব্যক্তিগত টেক্সট চ্যাট
- Discover-এ না দেখানোর privacy switch

## জরুরি সীমাবদ্ধতা
এটি প্রাথমিক MVP, Facebook/TikTok-এর সম্পূর্ণ বিকল্প নয়। এই সংস্করণে এখনো ছবি/ভিডিও পোস্ট, Reels প্লেয়ার, ভয়েস মেসেজ, অডিও/ভিডিও লাইভ কল, লাইক/কমেন্ট/শেয়ার ও রিপোর্ট/ব্লক ব্যবস্থা নেই। এগুলো পরবর্তী ধাপে যোগ করতে হবে।

## Firebase সেটআপ
1. Firebase Console → Authentication → Sign-in method → Email/Password চালু করুন।
2. Firestore Database তৈরি করুন।
3. Storage চালু করুন (Firebase Console-এর নির্দেশনা অনুসরণ করুন; কিছু প্রকল্পে billing plan লাগতে পারে)।
4. Firestore Rules-এ `firestore.rules` এবং Storage Rules-এ `storage.rules` প্রকাশ করুন।
5. `app/google-services.json`-এ Android package `com.fmessenger.chat`-এর সঠিক Firebase config থাকতে হবে।

## Build
GitHub Actions workflow দিয়ে `gradle assembleDebug` চালিয়ে `app/build/outputs/apk/debug/app-debug.apk` তৈরি করা যাবে। এটি debug APK; প্রকাশের আগে release signing, security rules review, abuse reporting/moderation ও privacy policy দরকার।


## অডিও ও ভিডিও কল (নতুন)
- চ্যাটের উপরের ফোন আইকনে চাপ দিলে অডিও কলের জন্য একটি আলাদা Jitsi Meet রুম তৈরি হয়।
- ভিডিও আইকনে চাপ দিলে ভিডিও কলের রুম তৈরি হয়।
- অ্যাপটি Firestore চ্যাটে আমন্ত্রণ লিংক পাঠায় এবং আপনার ফোনের ব্রাউজারে কল খুলে দেয়। অপর ব্যবহারকারী চ্যাটের আমন্ত্রণ লিংকে চাপ দিয়ে যোগ দিতে পারবেন।
- এই সংস্করণে কল ব্রাউজার-ভিত্তিক Jitsi Meet দিয়ে হয়; এটি এখনো অ্যাপের ভেতরে native WebRTC কল নয়। কলের জন্য ইন্টারনেট, ব্রাউজার এবং মাইক্রোফোন/ক্যামেরা অনুমতি প্রয়োজন। Jitsi Meet একটি তৃতীয় পক্ষের সেবা; সংবেদনশীল কথোপকথনের আগে এর গোপনীয়তা নীতি দেখে নিন।
- Production release-এর আগে নিজস্ব trusted calling service/TURN infrastructure, abuse controls এবং call notification ব্যবস্থা যোগ করে দুই বা ততোধিক বাস্তব ডিভাইসে পরীক্ষা করা প্রয়োজন।

## নেটিভ অডিও ও ভিডিও কল (WebRTC)

এই সংস্করণে কলের জন্য Android-এর WebRTC SDK ব্যবহার করা হয়েছে। কলের মিডিয়া (মাইক্রোফোন/ক্যামেরা) অ্যাপের ভিতরেই চালু হয়; Jitsi বা ব্রাউজার খোলে না। Firestore `calls` collection এবং তার `callerCandidates` / `calleeCandidates` subcollection দিয়ে কলের offer/answer ও ICE signaling আদান-প্রদান হয়।

### Firebase Rules আপডেট বাধ্যতামূলক

Firebase Console → Firestore Database → Rules-এ এই প্রজেক্টের `firestore.rules` ফাইলের সম্পূর্ণ নিয়ম প্রকাশ (Publish) করুন। পুরোনো Rules রেখে দিলে কল তৈরি বা signaling ব্যর্থ হবে। Firebase Storage Rules এই কল ফিচারের জন্য প্রয়োজন নেই।

### পরীক্ষা

1. দুটি আলাদা Android ফোনে অ্যাপ ইনস্টল করুন এবং দুটি আলাদা অ্যাকাউন্টে লগইন করুন।
2. এক ফোন থেকে অন্য ব্যবহারকারীর চ্যাট খুলে ফোন বা ভিডিও আইকনে চাপ দিন।
3. অপর ফোনে অ্যাপ খোলা/foreground-এ থাকলে Incoming Call ডায়ালগে কল ধরুন চাপ দিন।
4. প্রথম ব্যবহারে Camera ও Microphone permission দিন।

### নেটওয়ার্ক সীমাবদ্ধতা

এই build-এ STUN server দিয়ে সরাসরি peer-to-peer সংযোগ চেষ্টা করা হয়। কিছু মোবাইল নেটওয়ার্ক, কঠোর NAT বা firewall-এ কল সংযোগ নাও হতে পারে। নির্ভরযোগ্য production calling-এর জন্য নিজস্ব/বিশ্বস্ত TURN relay server এবং credentials কনফিগার করতে হবে। এই ZIP-এ TURN credentials রাখা হয়নি। অ্যাপটি foreground-এ থাকলে incoming call dialog দেখায়; বন্ধ/force-stop অবস্থায় ring notification পেতে Firebase Cloud Messaging (FCM) incoming-call push service আলাদাভাবে deploy করতে হবে।

## সংস্করণ 1.4 — Auto News ও In-app Video

- নিচের নেভিগেশনে ফিড, নিউজ, ভিডিও, মানুষ খুঁজুন ও প্রোফাইল ট্যাব।
- নিউজ ট্যাবে BBC বাংলা, প্রথম আলো, বাংলা ট্রিবিউন, বাংলানিউজ২৪, DW বাংলা, Al Jazeera, Google News বাংলাদেশ, NASA ও NPR-এর RSS/প্রকাশ্য ফিড থেকে শিরোনাম/সংক্ষিপ্ত বিবরণ আনার চেষ্টা করা হয়। ইন্টারনেট সংযোগ ও উৎসের সার্ভার/ফিড নীতির ওপর প্রাপ্যতা নির্ভর করে। কোনো উৎস কাজ না করলে অন্য উৎসগুলো দেখা যাবে।
- সংবাদ নির্বাচন করলে মূল প্রকাশকের ওয়েবসাইট অ্যাপের ভেতরের WebView-তে খোলে; প্রকাশকের কপিরাইট, ব্র্যান্ডিং ও ব্যবহারের শর্ত প্রযোজ্য। RSS বিনামূল্যে পড়া যায় মানেই বাণিজ্যিক পুনঃপ্রকাশের অনুমতি নয়; প্রকাশকের অনুমতি/লাইসেন্স নিতে হতে পারে।
- ভিডিও ট্যাবে YouTube-এ সার্চ, YouTube URL বা youtu.be URL, এবং Internet Archive/NASA-এর ভিডিও পেজ অ্যাপের ভেতরে WebView-তে খোলা যায়। HTML5/YouTube-এর নিজস্ব প্লেয়ার কন্ট্রোল বজায় থাকে এবং সমর্থিত হলে ফুলস্ক্রিন চলে। কিছু ভিডিও মালিক embedding বন্ধ করলে বা সাইট WebView ব্লক করলে মূল সাইটে দেখতে হবে।
- ভিডিও ডাউনলোড, বিজ্ঞাপন ব্লক, বা পেইড কনটেন্ট বাইপাস করা হয় না।

এই সংস্করণের APK GitHub Actions-এ বিল্ড ও বাস্তব Android ডিভাইসে পরীক্ষা করতে হবে। RSS উৎসের নেটওয়ার্ক/সার্ভার পরিবর্তনের কারণে সব ফিড সবসময় সচল থাকার নিশ্চয়তা নেই।
