package com.fmessenger.chat

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import org.webrtc.*
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

/** One-to-one native WebRTC call screen. Signalling is exchanged through Firestore. */
class NativeCallActivity : ComponentActivity() {
    private val db by lazy { FirebaseFirestore.getInstance() }
    private val uid get() = FirebaseAuth.getInstance().currentUser?.uid.orEmpty()
    private val callId by lazy { intent.getStringExtra("callId").orEmpty() }
    private val isCaller by lazy { intent.getBooleanExtra("isCaller", false) }
    private val isVideo by lazy { intent.getBooleanExtra("isVideo", true) }
    private val calls get() = db.collection("calls").document(callId)
    private var factory: PeerConnectionFactory? = null
    private var peer: PeerConnection? = null
    private var egl: EglBase? = null
    private var localRenderer: SurfaceViewRenderer? = null
    private var remoteRenderer: SurfaceViewRenderer? = null
    private var capturer: CameraVideoCapturer? = null
    private var videoSource: VideoSource? = null
    private var audioSource: AudioSource? = null
    private var localAudio: AudioTrack? = null
    private var localVideo: VideoTrack? = null
    private var callListener: ListenerRegistration? = null
    private var candidateListener: ListenerRegistration? = null
    private val seenCandidates = mutableSetOf<String>()
    private var remoteDescriptionSet = false
    private val pendingCandidates = mutableListOf<IceCandidate>()
    private lateinit var status: TextView
    private lateinit var root: LinearLayout
    private var muted = false
    private var cameraOff = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (callId.isBlank() || uid.isBlank()) { finish(); return }
        buildUi()
        val needed = if (isVideo) arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.CAMERA) else arrayOf(Manifest.permission.RECORD_AUDIO)
        if (needed.any { ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED }) {
            ActivityCompat.requestPermissions(this, needed, 44)
        } else startRtc()
    }

    private fun buildUi() {
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(12, 18, 12, 12); gravity = Gravity.CENTER; setBackgroundColor(0xFF10243D.toInt()) }
        status = TextView(this).apply { text = "কল সংযোগ হচ্ছে…"; textSize = 19f; setTextColor(-1); gravity = Gravity.CENTER }
        localRenderer = SurfaceViewRenderer(this)
        remoteRenderer = SurfaceViewRenderer(this)
        root.addView(status, LinearLayout.LayoutParams(-1, 56))
        root.addView(remoteRenderer!!, LinearLayout.LayoutParams(-1, 0, 1f))
        if (isVideo) root.addView(localRenderer!!, LinearLayout.LayoutParams(150, 210).apply { gravity = Gravity.END })
        val controls = LinearLayout(this).apply { gravity = Gravity.CENTER; orientation = LinearLayout.HORIZONTAL }
        fun control(label: String, color: Int = 0xFF247BDB.toInt(), action: () -> Unit) { controls.addView(Button(this@NativeCallActivity).apply { text = label; setTextColor(-1); setBackgroundColor(color); setOnClickListener { action() } }, LinearLayout.LayoutParams(0, 56, 1f).apply { setMargins(4, 10, 4, 4) }) }
        control("Mute") { muted = !muted; localAudio?.setEnabled(!muted) }
        control("Camera") { cameraOff = !cameraOff; localVideo?.setEnabled(!cameraOff) }
        control("কল কাটুন", 0xFFD32F2F.toInt()) { endCall(true) }
        root.addView(controls, LinearLayout.LayoutParams(-1, 70))
        setContentView(root)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 44 && grantResults.isNotEmpty() && grantResults.all { it == PackageManager.PERMISSION_GRANTED }) startRtc()
        else { status.text = "কলের জন্য মাইক্রোফোন ও ক্যামেরার অনুমতি প্রয়োজন" }
    }

    private fun startRtc() {
        try {
            PeerConnectionFactory.initialize(PeerConnectionFactory.InitializationOptions.builder(this).createInitializationOptions())
            egl = EglBase.create()
            localRenderer?.init(egl!!.eglBaseContext, null); remoteRenderer?.init(egl!!.eglBaseContext, null)
            localRenderer?.setMirror(true); remoteRenderer?.setMirror(false)
            factory = PeerConnectionFactory.builder().createPeerConnectionFactory()
            val ice = listOf(PeerConnection.IceServer.builder("stun:stun.l.google.com:19302").createIceServer())
            val config = PeerConnection.RTCConfiguration(ice).apply { sdpSemantics = PeerConnection.SdpSemantics.UNIFIED_PLAN }
            peer = factory!!.createPeerConnection(config, object : PeerConnection.Observer {
                override fun onSignalingChange(state: PeerConnection.SignalingState) {}
                override fun onIceConnectionChange(state: PeerConnection.IceConnectionState) { runOnUiThread { status.text = when (state) { PeerConnection.IceConnectionState.CONNECTED, PeerConnection.IceConnectionState.COMPLETED -> "কল সংযুক্ত"; PeerConnection.IceConnectionState.FAILED -> "সংযোগ ব্যর্থ—আবার চেষ্টা করুন"; PeerConnection.IceConnectionState.DISCONNECTED -> "সংযোগ বিচ্ছিন্ন"; else -> "কল সংযোগ হচ্ছে…" } } }
                override fun onIceConnectionReceivingChange(receiving: Boolean) {}
                override fun onIceGatheringChange(state: PeerConnection.IceGatheringState) {}
                override fun onIceCandidate(candidate: IceCandidate) { val side = if (isCaller) "callerCandidates" else "calleeCandidates"; calls.collection(side).add(mapOf("sdpMid" to candidate.sdpMid, "sdpMLineIndex" to candidate.sdpMLineIndex, "sdp" to candidate.sdp)).addOnFailureListener { runOnUiThread { status.text = "নেটওয়ার্ক সিগন্যাল পাঠানো যায়নি" } } }
                override fun onIceCandidatesRemoved(candidates: Array<out IceCandidate>) {}
                override fun onAddStream(stream: MediaStream) {}
                override fun onRemoveStream(stream: MediaStream) {}
                override fun onDataChannel(channel: DataChannel) {}
                override fun onRenegotiationNeeded() {}
                override fun onAddTrack(receiver: RtpReceiver, streams: Array<out MediaStream>) { val track = receiver.track(); if (track is VideoTrack) runOnUiThread { track.addSink(remoteRenderer!!) } }
            })
            audioSource = factory!!.createAudioSource(MediaConstraints())
            localAudio = factory!!.createAudioTrack("audio_$uid", audioSource)
            peer!!.addTrack(localAudio, listOf("fm-audio"))
            val enumerator = Camera2Enumerator(this)
            val camera = if (isVideo) enumerator.deviceNames.firstOrNull { enumerator.isFrontFacing(it) } ?: enumerator.deviceNames.firstOrNull() else null
            if (camera != null) {
                capturer = enumerator.createCapturer(camera, null)
                videoSource = factory!!.createVideoSource(false)
                val helper = SurfaceTextureHelper.create("FMessengerCamera", egl!!.eglBaseContext)
                capturer!!.initialize(helper, this, videoSource!!.capturerObserver)
                capturer!!.startCapture(640, 480, 24)
                localVideo = factory!!.createVideoTrack("video_$uid", videoSource)
                localVideo!!.addSink(localRenderer!!)
                peer!!.addTrack(localVideo, listOf("fm-video"))
            }
            listenForRemoteCandidates()
            listenForCallState()
            if (isCaller) createOffer()
        } catch (e: Exception) { status.text = "কল চালু করা যায়নি: ${e.localizedMessage ?: "ত্রুটি"}" }
    }

    private fun createOffer() {
        peer?.createOffer(object : SdpObserver {
            override fun onCreateSuccess(desc: SessionDescription) { peer?.setLocalDescription(object : SdpObserver { override fun onCreateSuccess(d: SessionDescription) { calls.update("offer", mapOf("type" to desc.type.canonicalForm(), "sdp" to desc.description)) }; override fun onSetSuccess() {}; override fun onCreateFailure(error: String) { fail(error) }; override fun onSetFailure(error: String) { fail(error) } }, desc) }
            override fun onSetSuccess() {}; override fun onCreateFailure(error: String) { fail(error) }; override fun onSetFailure(error: String) { fail(error) }
        }, MediaConstraints())
    }

    private fun listenForCallState() {
        callListener = calls.addSnapshotListener { snap, error ->
            if (error != null || snap == null || !snap.exists()) return@addSnapshotListener
            val state = snap.getString("status")
            if (state == "ended" || state == "rejected") { runOnUiThread { status.text = "কল শেষ হয়েছে"; finish() }; return@addSnapshotListener }
            if (!isCaller && !remoteDescriptionSet) {
                val offer = snap.get("offer") as? Map<*, *>
                if (offer != null) {
                    val sdp = offer["sdp"] as? String ?: return@addSnapshotListener
                    val type = offer["type"] as? String ?: "offer"
                    peer?.setRemoteDescription(object : SdpObserver {
                        override fun onSetSuccess() { remoteDescriptionSet = true; flushCandidates(); createAnswer() }
                        override fun onCreateSuccess(d: SessionDescription) {}; override fun onCreateFailure(e: String) { fail(e) }; override fun onSetFailure(e: String) { fail(e) }
                    }, SessionDescription(SessionDescription.Type.fromCanonicalForm(type), sdp))
                }
            }
            if (isCaller && !remoteDescriptionSet) {
                val answer = snap.get("answer") as? Map<*, *>
                if (answer != null) {
                    val sdp = answer["sdp"] as? String ?: return@addSnapshotListener
                    val type = answer["type"] as? String ?: "answer"
                    peer?.setRemoteDescription(object : SdpObserver { override fun onSetSuccess() { remoteDescriptionSet = true; flushCandidates() }; override fun onCreateSuccess(d: SessionDescription) {}; override fun onCreateFailure(e: String) { fail(e) }; override fun onSetFailure(e: String) { fail(e) } }, SessionDescription(SessionDescription.Type.fromCanonicalForm(type), sdp))
                }
            }
        }
    }

    private fun createAnswer() {
        peer?.createAnswer(object : SdpObserver {
            override fun onCreateSuccess(desc: SessionDescription) { peer?.setLocalDescription(object : SdpObserver { override fun onSetSuccess() { calls.update("answer", mapOf("type" to desc.type.canonicalForm(), "sdp" to desc.description)); calls.update("status", "active") }; override fun onCreateSuccess(d: SessionDescription) {}; override fun onCreateFailure(e: String) { fail(e) }; override fun onSetFailure(e: String) { fail(e) } }, desc) }
            override fun onSetSuccess() {}; override fun onCreateFailure(e: String) { fail(e) }; override fun onSetFailure(e: String) { fail(e) }
        }, MediaConstraints())
    }

    private fun listenForRemoteCandidates() {
        val side = if (isCaller) "calleeCandidates" else "callerCandidates"
        candidateListener = calls.collection(side).addSnapshotListener { snap, _ -> snap?.documentChanges?.forEach { change ->
            if (change.type.name == "ADDED" && seenCandidates.add(change.document.id)) {
                val d = change.document
                val mid = d.getString("sdpMid") ?: return@forEach
                val line = (d.getLong("sdpMLineIndex") ?: 0L).toInt(); val sdp = d.getString("sdp") ?: return@forEach
                val candidate = IceCandidate(mid, line, sdp)
                if (remoteDescriptionSet) peer?.addIceCandidate(candidate) else pendingCandidates.add(candidate)
            }
        } }
    }
    private fun flushCandidates() { pendingCandidates.forEach { peer?.addIceCandidate(it) }; pendingCandidates.clear() }
    private fun fail(message: String) { runOnUiThread { status.text = "কল সমস্যা: $message" } }
    private fun endCall(updateServer: Boolean) { if (updateServer) calls.update("status", "ended"); finish() }
    override fun onDestroy() {
        callListener?.remove(); candidateListener?.remove()
        try { capturer?.stopCapture() } catch (_: Exception) {}
        capturer?.dispose(); localAudio?.dispose(); localVideo?.dispose(); audioSource?.dispose(); videoSource?.dispose(); peer?.close(); peer?.dispose(); factory?.dispose()
        localRenderer?.release(); remoteRenderer?.release(); egl?.release()
        super.onDestroy()
    }
}
