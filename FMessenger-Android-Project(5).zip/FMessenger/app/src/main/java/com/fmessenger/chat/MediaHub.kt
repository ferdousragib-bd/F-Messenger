package com.fmessenger.chat

import android.annotation.SuppressLint
import android.app.Activity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import org.xmlpull.v1.XmlPullParser
import org.xmlpull.v1.XmlPullParserFactory
import java.net.HttpURLConnection
import java.net.URL

private data class RssSource(val title: String, val url: String, val group: String)
private data class RssStory(val title: String, val link: String, val description: String, val source: String)

private val rssSources = listOf(
    RssSource("BBC বাংলা", "https://feeds.bbci.co.uk/bengali/rss.xml", "বাংলা সংবাদ"),
    RssSource("প্রথম আলো", "https://www.prothomalo.com/feed/", "বাংলাদেশ"),
    RssSource("বাংলা ট্রিবিউন", "https://www.banglatribune.com/feed/", "বাংলাদেশ"),
    RssSource("বাংলানিউজ২৪", "https://www.banglanews24.com/rss/rss.xml", "বাংলাদেশ"),
    RssSource("DW বাংলা", "https://rss.dw.com/rdf/rss-bn-all", "বাংলা সংবাদ"),
    RssSource("Al Jazeera", "https://www.aljazeera.com/xml/rss/all.xml", "বিশ্ব সংবাদ"),
    RssSource("Google News বাংলাদেশ", "https://news.google.com/rss?hl=bn&gl=BD&ceid=BD:bn", "বাংলা সংবাদ"),
    RssSource("NASA", "https://www.nasa.gov/feed/", "বিজ্ঞান ও প্রযুক্তি"),
    RssSource("NPR", "https://feeds.npr.org/1001/rss.xml", "বিশ্ব সংবাদ")
)

private suspend fun readRss(source: RssSource): List<RssStory> = withContext(Dispatchers.IO) {
    val connection = (URL(source.url).openConnection() as HttpURLConnection).apply {
        connectTimeout = 8000; readTimeout = 10000
        setRequestProperty("User-Agent", "FMessenger/1.0 (Android RSS Reader)")
    }
    try {
        connection.inputStream.use { input ->
            val parser = XmlPullParserFactory.newInstance().newPullParser()
            parser.setInput(input, null)
            val result = mutableListOf<RssStory>()
            var event = parser.eventType
            var insideItem = false
            var title = ""; var link = ""; var description = ""
            var count = 0
            while (event != XmlPullParser.END_DOCUMENT && count < 30) {
                when (event) {
                    XmlPullParser.START_TAG -> when (parser.name.lowercase()) {
                        "item", "entry" -> { insideItem = true; title = ""; link = ""; description = "" }
                        "title" -> if (insideItem) title = parser.nextText().trim()
                        "link" -> if (insideItem) {
                            val href = parser.getAttributeValue(null, "href")
                            link = (href ?: parser.nextText()).trim()
                        }
                        "description", "summary", "content:encoded" -> if (insideItem) description = parser.nextText().replace(Regex("<[^>]*>"), " ").trim()
                    }
                    XmlPullParser.END_TAG -> if (parser.name.equals("item", true) || parser.name.equals("entry", true)) {
                        if (title.isNotBlank() && link.startsWith("http")) {
                            result.add(RssStory(title, link, description.take(400), source.title)); count++
                        }
                        insideItem = false
                    }
                }
                event = parser.next()
            }
            result
        }
    } finally { connection.disconnect() }
}

@Composable
fun NewsHubScreen() {
    var stories by remember { mutableStateOf<List<RssStory>>(emptyList()) }
    var loading by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("সংবাদ লোড করতে রিফ্রেশ চাপুন") }
    var selectedUrl by remember { mutableStateOf<String?>(null) }
    var selectedTitle by remember { mutableStateOf("") }
    var refreshKey by remember { mutableIntStateOf(0) }
    LaunchedEffect(refreshKey) {
        loading = true
        val results = coroutineScope { rssSources.map { source -> async { runCatching { readRss(source) }.getOrElse { emptyList() } } }.awaitAll() }
        stories = results.flatten().distinctBy { it.link }.take(100)
        val failures = results.count { it.isEmpty() }
        message = if (stories.isEmpty()) "এই মুহূর্তে ফিড পাওয়া যায়নি। ইন্টারনেট সংযোগ পরীক্ষা করে রিফ্রেশ করুন।" else "${stories.size}টি প্রকাশ্য সংবাদ পাওয়া গেছে${if (failures > 0) " · কিছু উৎস পাওয়া যায়নি" else ""}"
        loading = false
    }
    if (selectedUrl != null) {
        Column(Modifier.fillMaxSize()) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth().padding(8.dp)) {
                IconButton(onClick = { selectedUrl = null }) { Icon(Icons.Default.ArrowBack, null) }
                Text(selectedTitle, fontWeight = FontWeight.Bold, maxLines = 1)
            }
            InAppWebPage(selectedUrl!!, Modifier.weight(1f))
        }
    } else {
        Column(Modifier.fillMaxSize().padding(horizontal = 12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) { Text("Auto Free News", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold); Text("প্রকাশ্য RSS সংবাদ উৎস", style = MaterialTheme.typography.bodySmall) }
                IconButton(onClick = {
                    loading = true
                    refreshKey++
                }) { Icon(Icons.Default.Refresh, "রিফ্রেশ") }
            }
            Text(message, style = MaterialTheme.typography.bodySmall)
            if (loading) LinearProgressIndicator(Modifier.fillMaxWidth())
            LazyColumn(contentPadding = PaddingValues(bottom = 12.dp)) {
                items(stories) { story ->
                    Card(Modifier.fillMaxWidth().padding(vertical = 4.dp).clickable { selectedTitle = story.title; selectedUrl = story.link }, shape = RoundedCornerShape(12.dp)) {
                        Column(Modifier.padding(12.dp)) {
                            Text(story.source, color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.labelMedium)
                            Text(story.title, fontWeight = FontWeight.SemiBold)
                            if (story.description.isNotBlank()) Text(story.description, maxLines = 3, style = MaterialTheme.typography.bodySmall)
                            Text("মূল সাইটে পড়ুন", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.labelMedium)
                        }
                    }
                }
                item { Text("উৎস: ${rssSources.joinToString(" · ") { it.title }}", style = MaterialTheme.typography.labelSmall, modifier = Modifier.padding(8.dp)) }
            }
        }
    }
}

@Composable
fun VideoHubScreen() {
    var query by remember { mutableStateOf("বাংলা সংবাদ ও শিক্ষামূলক ভিডিও") }
    var activeUrl by remember { mutableStateOf<String?>(null) }
    var title by remember { mutableStateOf("ভিডিও প্লেয়ার") }
    if (activeUrl != null) {
        Column(Modifier.fillMaxSize()) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp)) {
                IconButton(onClick = { activeUrl = null }) { Icon(Icons.Default.ArrowBack, null) }
                Text(title, fontWeight = FontWeight.Bold)
            }
            InAppWebPage(activeUrl!!, Modifier.weight(1f))
            Text("ভিডিওর নিজস্ব প্লেয়ার ও বিজ্ঞাপন/কন্ট্রোল উৎস সাইটের নিয়ম অনুযায়ী থাকবে।", style = MaterialTheme.typography.labelSmall, modifier = Modifier.padding(8.dp))
        }
    } else {
        Column(Modifier.fillMaxSize().padding(12.dp)) {
            Text("ভিডিও ও ফ্রি সাইট", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Text("YouTube-এর অফিসিয়াল এমবেড প্লেয়ার এবং প্রকাশ্য ভিডিও সাইট", style = MaterialTheme.typography.bodySmall)
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(query, { query = it }, modifier = Modifier.fillMaxWidth(), label = { Text("ভিডিও খুঁজুন") }, singleLine = true)
            Button(onClick = { if (query.isNotBlank()) { title = query; activeUrl = videoTarget(query) } }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.PlayArrow, null); Text("অ্যাপের ভেতরে ভিডিও খুঁজুন") }
            Text("URL দিলে সরাসরি চালান; সার্চ লিখলে YouTube-এ খুঁজবে। ভিডিও এমবেড অনুমতি থাকলে অ্যাপের ভেতরেই চলবে।", style = MaterialTheme.typography.labelSmall)
            Text("জনপ্রিয় ফ্রি ভিডিও উৎস", fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 12.dp, bottom = 6.dp))
            val sources = listOf(
                "YouTube · সংবাদ ও বিনোদন" to "https://www.youtube.com/results?search_query=Bangla+news+official",
                "YouTube · শিক্ষা" to "https://www.youtube.com/results?search_query=free+education+Bangla",
                "YouTube · প্রযুক্তি" to "https://www.youtube.com/results?search_query=technology+Bangla",
                "Internet Archive · Public domain video" to "https://archive.org/details/movies",
                "NASA · ভিডিও" to "https://www.nasa.gov/nasa-videos/"
            )
            LazyColumn { items(sources) { (name, url) -> ListItem(headlineContent = { Text(name) }, supportingContent = { Text("সাইটের নিজস্ব প্লেয়ার") }, leadingContent = { Icon(Icons.Default.PlayArrow, null) }, modifier = Modifier.clickable { title = name; activeUrl = url }); HorizontalDivider() } }
            Text("নোট: কিছু ভিডিওর মালিক এমবেড বন্ধ রাখলে সেটি মূল সাইটে খুলতে হবে।", style = MaterialTheme.typography.labelSmall, modifier = Modifier.padding(top = 8.dp))
        }
    }
}

private fun videoTarget(input: String): String {
    val value = input.trim()
    val id = when {
        value.contains("youtube.com/watch") -> Regex("[?&]v=([^&]+)").find(value)?.groupValues?.getOrNull(1)
        value.contains("youtu.be/") -> value.substringAfter("youtu.be/").substringBefore("?").substringBefore("/")
        else -> null
    }
    return if (!id.isNullOrBlank()) "https://www.youtube.com/watch?v=$id" else
        if (value.startsWith("https://") || value.startsWith("http://")) value
        else "https://www.youtube.com/results?search_query=" + java.net.URLEncoder.encode(value, "UTF-8")
}

private class FullscreenChromeClient(private val activity: Activity, private val webView: WebView) : WebChromeClient() {
    private var customView: View? = null
    private var callback: CustomViewCallback? = null
    private var originalVisibility: Int = View.VISIBLE
    override fun onShowCustomView(view: View, customViewCallback: CustomViewCallback) {
        if (customView != null) { customViewCallback.onCustomViewHidden(); return }
        customView = view; callback = customViewCallback
        originalVisibility = webView.visibility
        webView.visibility = View.GONE
        val decor = activity.window.decorView as? FrameLayout ?: return
        decor.addView(view, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
    }
    override fun onHideCustomView() {
        val view = customView ?: return
        (view.parent as? ViewGroup)?.removeView(view)
        customView = null
        webView.visibility = originalVisibility
        callback?.onCustomViewHidden(); callback = null
    }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
private fun InAppWebPage(url: String, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    AndroidView(modifier = modifier.fillMaxWidth(), factory = {
        WebView(context).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.mediaPlaybackRequiresUserGesture = true
            settings.loadWithOverviewMode = true
            settings.useWideViewPort = true
            webChromeClient = (context as? Activity)?.let { FullscreenChromeClient(it, this) } ?: WebChromeClient()
            webViewClient = WebViewClient()
            loadUrl(url)
        }
    }, update = { view -> if (view.url != url) view.loadUrl(url) })
}
